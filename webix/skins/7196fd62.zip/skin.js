//[Skin Customization]
webix.skin.contrast.barHeight=40;webix.skin.contrast.tabbarHeight=40;webix.skin.contrast.rowHeight=34;webix.skin.contrast.listItemHeight=34;webix.skin.contrast.inputHeight=24;webix.skin.contrast.layoutMargin.wide=5;webix.skin.contrast.layoutMargin.space=5;webix.skin.contrast.layoutPadding.space=5;
 webix.skin.set('contrast')